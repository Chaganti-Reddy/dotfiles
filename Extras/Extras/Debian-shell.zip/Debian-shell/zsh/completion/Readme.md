# Run this command in terminal
            sudo chmod -R 755 /home/reddy/.config/zsh/
